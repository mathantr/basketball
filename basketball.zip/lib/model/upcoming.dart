class UpcomingCat {
  final String iUrl;
  final String iColor;
  final String iBgColor;
  UpcomingCat(
      {required this.iUrl, required this.iColor, required this.iBgColor});
}
