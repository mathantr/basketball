import 'package:flutter/material.dart';

class TabLineScreen extends StatefulWidget {
  const TabLineScreen({super.key});

  @override
  State<TabLineScreen> createState() => _TabLineScreenState();
}

class _TabLineScreenState extends State<TabLineScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 3,
        child: new Scaffold(
          backgroundColor: Colors.transparent,
          appBar: new PreferredSize(
            preferredSize: Size.fromHeight(kToolbarHeight),
            child: new Container(
              color: Colors.transparent,
              child: new SafeArea(
                child: Column(
                  children: <Widget>[
                    new Expanded(child: new Container()),
                    new TabBar(
                      tabs: [
                        new Text("Lunches"),
                        new Text("Cart"),
                        new Text("Wallet"),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          body: new TabBarView(
            children: <Widget>[
              new Column(
                children: <Widget>[new Text("Lunches Page")],
              ),
              new Column(
                children: <Widget>[new Text("Cart Page")],
              ),
              new Column(
                children: <Widget>[new Text("Home")],
              ),
            ],
          ),
        ));
  }
}
