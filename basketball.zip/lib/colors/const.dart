import 'package:flutter/animation.dart';

final black = Color.fromRGBO(23, 28, 40, 1);
final lightBlack = Color.fromRGBO(30, 37, 46, 1);
final liteGreen = Color.fromRGBO(151, 233, 164, 1);
final white = Color.fromRGBO(251, 251, 251, 1);
final blue = Color.fromRGBO(50, 64, 134, 1);
