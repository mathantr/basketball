import 'package:basketball/colors/const.dart';
import 'package:flutter/material.dart';

class UefaChampian extends StatelessWidget {
  const UefaChampian({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 175,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: lightBlack,
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'UEFA Champions League',
                  style: TextStyle(
                    fontSize: 16,
                    color: white,
                  ),
                ),
                Text(
                  '02/11/22',
                  style: TextStyle(
                    fontSize: 16,
                    color: white.withOpacity(0.4),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Pick type: Spread',
                  style: TextStyle(
                    fontSize: 14,
                    color: white.withOpacity(0.4),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Manchester City',
                  style: TextStyle(fontSize: 12, color: white.withOpacity(0.6)),
                )
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Row(
              children: [
                Container(
                  height: 40,
                  width: 70,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: liteGreen),
                  child: Center(
                      child: Text(
                    'Win',
                    style: TextStyle(fontSize: 16, color: black),
                  )),
                ),
                SizedBox(
                  width: 15,
                ),
                Text(
                  'Profit:',
                  style: TextStyle(
                    color: white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                SizedBox(
                  width: 5,
                ),
                Text(
                  '10.20 Units',
                  style: TextStyle(
                    color: liteGreen.withOpacity(0.7),
                    fontSize: 14,
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
